const s="/assets/easy-bpm-EFOVOnGs.svg";export{s as e};
